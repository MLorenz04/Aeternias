# Aeternias, srdce světa
Aeternias je platforma umožňující hráčům Dračího doupěte, roleplayů či fanouškům Fantasy generovat bitvy jak mezi malou skupinkou lidí, tak velkými armádami. Aeternias umožňuje vytvářet vlastní světy, které mohou sloužit pro ukládání pokroku mezi game-sessiony v Dračím Doupěti či ukazovat bitvy mezi hráči v fantasy roleplayích.

Projekt je zcela free-to-use a i v budoucnu se bude co nejvíce snažit jím zůstat.

***

Odkaz: **Aeternias.cz**

Momentální verze: **1.0.2**

Vývojář: **Matyáš Lorenz**

