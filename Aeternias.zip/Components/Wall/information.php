<?php
/* Konfigurační soubor */
require "../../config.php";
?>
<h1 class="text-center wall-header"> Informace </h1>
<p class="px-4 py-3"> 
Aeternias je studentský projekt zaměřující se na generování fantasy bitev určený pro hráče roleplayů, dračího doupěte nebo jen fanoušky fantasy.
Projekt je veřejně dostupný pro každého a je zcela zdarma. Nebojte se nám v případě jakéhokoliv nápadu, připomínky či problému napsat!
<p>

</p>