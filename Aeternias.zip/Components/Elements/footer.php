<footer>
<script src="/Omega/Source/JS/Ajax/Reload_wall.js"></script>
</footer>
</body>
</html>